﻿using System;
namespace CountingKs.Services
{
  public interface ICountingKsIdentityService
  {
    string CurrentUser { get; }
  }
}
